import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categoryball',
  templateUrl: './categoryball.component.html',
  styleUrls: ['./categoryball.component.css']
})
export class CategoryballComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
