import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnew-book',
  templateUrl: './addnew-book.component.html',
  styleUrls: ['./addnew-book.component.css']
})
export class AddnewBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
