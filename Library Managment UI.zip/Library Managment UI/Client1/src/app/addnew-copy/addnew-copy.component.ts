import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnew-copy',
  templateUrl: './addnew-copy.component.html',
  styleUrls: ['./addnew-copy.component.css']
})
export class AddnewCopyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
