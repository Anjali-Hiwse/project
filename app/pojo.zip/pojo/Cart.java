package com.app.pojo;

public class Cart 
{
 private Customers cus_id;
 private Product prod_id;
 private double price;
}
