package com.app.pojo;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.*;


@Entity
@Table(name="Employees")
public class Employees 
{
  private Integer emp_id;
  private String name;
  private Address addr_id;
  private Date join_date;
  private byte[] image;
  private Role role_id;
public Employees(String name, Date join_date, byte[] image) {
	super();
	this.name = name;
	this.join_date = join_date;
	this.image = image;
}

@Id
public Integer getEmp_id() {
	return emp_id;
}
public void setEmp_id(Integer emp_id) {
	this.emp_id = emp_id;
}
@Column(length = 20)
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@OneToOne(mappedBy = "addr_id", cascade = CascadeType.ALL)
public Address getAddr_id() {
	return addr_id;
}
public void setAddr_id(Address addr_id) {
	this.addr_id = addr_id;
}
@Temporal(TemporalType.DATE)
@Column(name = "join_date")
public Date getJoin_date() {
	return join_date;
}
public void setJoin_date(Date join_date) {
	this.join_date = join_date;
}
public byte[] getImage() {
	return image;
}
public void setImage(byte[] image) {
	this.image = image;
}
@Enumerated(EnumType.ORDINAL)
public Role getRole_id() {
	return role_id;
}
public void setRole_id(Role role_id) {
	this.role_id = role_id;
}
@Override
public String toString() {
	return "Employees [emp_id=" + emp_id + ", name=" + name + ", join_date=" + join_date + ", image="
			+ Arrays.toString(image) + "]";
}
  
  
}
