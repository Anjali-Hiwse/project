
package com.app.pojo;

public class Address 
{
   private Integer addr_id;
   private String flat_no;
   private String street;
   private String addrLine1;
   private String addrLine2;
   private String city;
   private String state;
   private int pincode;
   private int contact_no;
   private Customers cus_id;
}
