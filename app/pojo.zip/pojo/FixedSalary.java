package com.app.pojo;

public class FixedSalary 
{
   private double per_day_salary;
   private double per_hour_salary;
   private Role role;
   
}
