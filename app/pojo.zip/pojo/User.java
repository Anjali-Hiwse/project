package com.app.pojo;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "User")
public class User 
{
  private Integer user_id;
  private String email;
  private String password;
  private Role role;
public User(String email, String password, Role role) {
	super();
	this.email = email;
	this.password = password;
	this.role = role;
}

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getUser_id() {
	return user_id;
}
public void setUser_id(Integer user_id) {
	this.user_id = user_id;
}
@Column(length = 30,nullable = false,unique = true)
@Pattern(regexp = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Column(length = 16,nullable = false)
@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})")
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Enumerated(EnumType.ORDINAL)
@Column(length = 20)
public Role getRole() {
	return role;
}
public void setRole(Role role) {
	this.role = role;
}
@Override
public String toString() {
	return "User [user_id=" + user_id + ", email=" + email + ", password=" + password + ", role=" + role + "]";
}

  
  
}
