package com.app.pojo;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.*;




@Entity
@Table(name = "Customers")
public class Customers 
{
  private Integer cus_id;
  private String name;
  private int phone_no;
  private Address addr_id;
  private User user_id;
  private Date reg_date;
  private byte[] image;
public Customers(Integer cus_id,String name, int phone_no, Date reg_date, byte[] image) {
	super();
	this.cus_id = cus_id;
	this.name = name;
	this.phone_no = phone_no;
	this.reg_date = reg_date;
	this.image = image;
}
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getCus_id() {
	return cus_id;
}
public void setCus_id(Integer cus_id) {
	this.cus_id = cus_id;
}
@Column(length = 20)
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public int getPhone_no() {
	return phone_no;
}
public void setPhone_no(int phone_no) {
	this.phone_no = phone_no;
}
@OneToMany(mappedBy = "cus_id", cascade = CascadeType.ALL, orphanRemoval = true)
public Address getAddr_id() {
	return addr_id;
}
public void setAddr_id(Address addr_id) {
	this.addr_id = addr_id;
}
@OneToOne(mappedBy = "user_id",cascade = CascadeType.ALL,orphanRemoval = true)
public User getUser_id() {
	return user_id;
}
public void setUser_id(User user_id) {
	this.user_id = user_id;
}
@Temporal(TemporalType.DATE)
@Column(name = "reg_date")
public Date getReg_date() {
	return reg_date;
}
public void setReg_date(Date reg_date) {
	this.reg_date = reg_date;
}

public byte[] getImage() {
	return image;
}
public void setImage(byte[] image) {
	this.image = image;
}
@Override
public String toString() {
	return "Customers [cus_id=" + cus_id + ", name=" + name + ", phone_no=" + phone_no + ", reg_date=" + reg_date
			+ ", image=" + Arrays.toString(image) + "]";
}
  
  
}
