package com.app.pojo;

import java.util.Date;

public class PaymentCardDetails 
{
  private Integer card_number;
  private int cvv;
  private Date exp_date;
  private Customers cus_id;
}
