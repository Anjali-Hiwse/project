package com.app.pojo;

public class FeedbackProduct 
{
  private Integer feedbackprod_id;
  private Customers cus_id;
  private Product prod_id;
  private String feedback;
  private int rating;
  private byte[] image;
  
}
