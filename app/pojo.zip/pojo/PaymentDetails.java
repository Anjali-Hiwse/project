package com.app.pojo;

public class PaymentDetails 
{
 private Integer pay_id;
 private String payment_method;
 private String payment_status;
}
