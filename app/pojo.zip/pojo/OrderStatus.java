package com.app.pojo;

public enum OrderStatus {
Delivered, Out_For_Delivery, Cancelled,To_Be_Delivered
}
