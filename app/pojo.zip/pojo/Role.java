package com.app.pojo;

public enum Role {
 ADMIN,SHOP_MANAGER,DELIVERY_PERSON,SUPPORT_STAFF,CUSTOMER
}
