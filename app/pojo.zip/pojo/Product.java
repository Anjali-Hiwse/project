package com.app.pojo;

public class Product
{
	private Integer prod_id;
	private String name;
	private String description_title;
	private String description;
	private double price;
	private Category category_id;
	private String shelf_life;
	private int quantity;
	private byte[] image;

}
