package com.app.pojo;

import java.util.Date;

public class Attendance 
{
 private Date month; //??????????????
 private int leaves;
 private int working_days;
 private int overtime;
 private Employees emp_id;
}
