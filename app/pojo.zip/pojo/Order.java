package com.app.pojo;

public class Order 
{
	private Integer order_id;
	private Address addr_id;
	private double total;
	private int estimated_delivery_time;
	private int delivery_time;
	private PaymentDetails pay_id;
	private OrderStatus status;
	private Employees emp_id;
	

}
