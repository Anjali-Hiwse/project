package com.app.pojo;

public class Category 
{
   private Integer category_id;
   private Categoryenum category;
}
  