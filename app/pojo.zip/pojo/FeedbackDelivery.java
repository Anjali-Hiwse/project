package com.app.pojo;

public class FeedbackDelivery 
{
  private Integer feedbackdev_id;
  private Customers cus_id;
  private Employees emp_id;
  private String feedback;
  private int rating;
}
