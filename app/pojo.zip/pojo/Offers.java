package com.app.pojo;

public class Offers 
{
   private Integer offer_id;
   private int discount;
   private Category category_id;
   private Product prod_id;
}
	