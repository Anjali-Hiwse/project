package com.app.pojo;

import java.util.Date;

public class Salary 
{
  private Date month;
  private double working_days_salary;
  private double overtime_salary;
  private double bonus;
  private double total_salary;
  private Employees emp_id;
}
